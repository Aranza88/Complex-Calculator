#ifndef OPERACION_H_INCLUDED
#define OPERACION_H_INCLUDED

int calcular(int op3,int op4,TToken *tokenActual);
void answer(TLista *listaPosfija);

#endif // OPERACION_H_INCLUDED
