# listaSimplementeLigada
Lista simplemente ligada: basica

Lista simplemente ligada. Cada nodo contiene una liga al siguienet elemento y un campo de informacion
Las operaciones básicas que se ofrecen son: agregar informacion iterar sobre la lista


La funcion iterar es interesante porque muestra cómo se puede proporcionar una función como parámetro para ser usado dentro de otra funcion, de esta manera la función iterar puede emplearse para aplicar a todos los nodos acciones definidas por medio de otra funcion. Vea el uso en la linea 20 del archivo main.c




