#include <stdlib.h>
#include <stdio.h>
#include "lista.h"
#include "pila.h"
#include "Tokens.h"
#include "posfija.h"

int precedencia(void *op){
    if(op=='^')
        return 3;
    if(op=='/' || op=='*')
        return 2;
    if(op=='+' || op=='-')
        return 1;
}

int mayorPrecedencia(void *op1,void *op2){
    if (precedencia(op1)>precedencia(op2))
        return 1;
    return 0;
}

TLista *posfija(TLista *listaInfija,TLista *listaPosfija){
    //crear pila;
    TPila *p=nuevaPila();
    TNodo *q;
    q=listaInfija->h;
    while(q!=NULL){
        if (((TToken *)(q->dato))->tipo==0)
            push(p,((TToken *)(q->dato))->token);
            //agregar a lista posfija
        else if (((TToken *)(q->dato))->tipo==1 || ((TToken *)(q->dato))->tipo==2){
            /*pila no vac�a, no sea ( y el operador en el stack tiene mayor presendencia que el que queremos agregar*/
            while(!vacia(p) && ((TToken *)(q->dato))->token!='(' && mayorPrecedencia(p->p[p->tos],(TToken *)(q->dato))->token)){
                //agregar a lista posfija el tope de la pila
                agregarNodo(listaPosfija,p->p[p->tos]);
                //hacer pop a la pila
                pop(p);
            }
            //push a la pila el operador siguiente
        }else if (((TToken *)(q->dato))->tipo==3 && ((TToken *)(q->dato))->token=='('/*el operador es (*/){
            push(p,((TToken *)(q->dato))->token);
            //push a la pila
        }else if(/*el operador es )*/){
            while(/*pila no vacia y no sea (*/){
                //agregar a lista posfija el tope de la pila
                agregarNodo(listaPosfija,p->p[p->tos]);
                //hacer pop a la pila
                pop(p);
            }
            //hacer pop a la pila
            pop(p);
        }
        q=q->s;
    }
    while(!vacia(p)/*pila no vacia*/){
        //agregar a lista posfija el tope de la pila
        agregarNodo(listaPosfija,p->p[p->tos]);
        //hacer pop a la pila
        pop(p);
    }
    return listaPosfija;
}
