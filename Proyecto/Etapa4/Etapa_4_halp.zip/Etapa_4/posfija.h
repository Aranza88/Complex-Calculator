#ifndef POSFIJA_H_INCLUDED
#define POSFIJA_H_INCLUDED

int precedencia(void *op);
int mayorPrecedencia(void *op1,void *op2);
TLista *posfija(TLista *listaInfija,TLista *listaPosfija);

#endif // POSFIJA_H_INCLUDED
