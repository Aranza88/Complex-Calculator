#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "lista.h"
#include "pila.h"
#include "Tokens.h"
#include "posfija.h"

int pCerrado(void *a){
    char aux[2];
    char p[] = ")";
    strcpy(aux,((TToken *)a)->token); //token
    if(!strcmp(aux,p))
        return 1;
   return 0;
}

int pAbierto(void *a){
    char aux[2];
    char p[] ="(";
    strcpy(aux,((TToken *)a)->token); //token
    if(!strcmp(aux,p))
        return 1;
   return 0;
}

int precedencia(char op){
/*    if(op=='(' || op==')')
 *       return 5;
 */   if( op=='=')
        return 4;
    if( op=='^')
        return 3;
    if( op=='/' || op=='*')
        return 2;
    if( op=='+' || op=='-')
        return 1;
    return 0;
}

int mayorPrecedencia(char op1,char op2){
    if (precedencia(op1)>precedencia(op2))
        return 1;
    return 0;
}

TLista *posfija(TLista *listaInfija){
    TLista *listaPosfija=nuevaLista(sizeof(TToken));
    // TPila *p=nuevaPila(sizeof(TToken),100);
    TToken *aux;
    while (!listaVacia(listaInfija)) {
        printf("Voy a retirar");
        retirarNodo(listaInfija,(void **)&aux);
        agregarNodo(listaPosfija,aux);
        printf("posfija: token: %s [%s]\n",strToken[aux->tipo],aux->token);
    }
    return listaPosfija;
}










