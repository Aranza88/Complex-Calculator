#ifndef POSFIJA_H_INCLUDED
#define POSFIJA_H_INCLUDED

TLista *posfija(TLista *listaInfija);

#endif // POSFIJA_H_INCLUDED
