#ifndef OPERACION_H_INCLUDED
#define OPERACION_H_INCLUDED

void answer(TLista *listaPosfija);

#endif // OPERACION_H_INCLUDED
