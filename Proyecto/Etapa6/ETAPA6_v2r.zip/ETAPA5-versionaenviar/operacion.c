#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "pila.h"
#include "lista.h"
#include "Tokens.h"
#include "operacion.h"

typedef struct{
    char Nombre[20];
    float Cantidad;
}TVariable;

int compara(void *dato1, void *dato2);


void answer(TLista *listaPosfija){
    TPila *operacion=nuevaPila(sizeof(TToken),100);
    TLista *var = nuevaLista(sizeof(float));
    TVariable p, *q;
    TToken *tokenActual;
    float op3,op4, resultado;
    char nombre[20];
    TToken *resultado2=malloc(sizeof(TToken));
    TToken *op1=malloc(sizeof(TToken));
    TToken *op2=malloc(sizeof(TToken));
    //
    while(!listaVacia(listaPosfija)){
        retirarNodo(listaPosfija,(void **)&tokenActual);
        if(tokenActual->tipo==numero||tokenActual->tipo==variable)
        {
            if (tokenActual->tipo==variable){
            do {
                q=buscarNodo(var,&p,compara);
                if (q==NULL){
                    printf("\nNo existe\n");
                    printf("\n Cual es el nombre de la variable?\n");
                    scanf("%s",p.Nombre);
                    printf("\nQue cantidad contiene?\n");
                    scanf("%f",&(p.Cantidad));
                    //printf("\n\n%f fue la cantidad a�adida\n",p.Cantidad);
                    agregarNodo(var,&p);
                }
                else{
                    printf("\n\nconfirmo que ya tiene el nodo");
                    printf("\n%s\n",q->Nombre);
                    printf("\n%f\n",((TVariable *)q)->Cantidad);
                }
            }while (q==NULL);
            //printf("%f",q->Cantidad);
            gcvt(q->Cantidad,4,tokenActual->token);
            printf("%s",tokenActual->token);
            }
            push(operacion,tokenActual);
        }
        else if(tokenActual->tipo==operador)
        {
            pop(operacion,op2);
            pop(operacion,op1);
            op3= atof(op1->token);
            op4= atof(op2->token);
            if(strcmp((tokenActual->token),"+")==0)
                resultado=op3+op4;
            else if(strcmp((tokenActual->token),"-")==0)
                resultado=op3-op4;
            else if(strcmp((tokenActual->token),"*")==0)
                resultado=op3*op4;
            else if(strcmp((tokenActual->token),"/")==0)
                resultado=op3/op4;
            else if(strcmp((tokenActual->token),"^")==0)
                resultado=pow(op3,op4);
            gcvt(resultado,4,resultado2->token);
            push(operacion,resultado2);
        }
     }
    if(operacion->tos==0){
        printf("\n\n\tResultado final: %s\n\n",resultado2->token);
    }
    else{
        printf("\n\n\t--- ERROR EN LAS OPERACIONES ---\n");
    }
     }


int compara(void *x, void *y) {
    if (strcmp(((TVariable *)x)->Nombre,((TVariable *)y)->Nombre)==0)
        return 0;
    return 1;
}
