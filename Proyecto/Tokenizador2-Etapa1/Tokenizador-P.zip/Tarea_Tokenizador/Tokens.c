#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Tokens.h"

char strToken[][11] = {"operador", "numero", "variable", "parentesis"};

int esOperador(char c){
    int k;
    static char operadores[] = "+-*/^";
    for (k=0; k<strlen(operadores); k++)
        if (c == operadores[k])
            return 1;
    return 0;
}

int esParentesis(char c) {
// si c es un caracter correspondiente a un parentesis regresa 1 si no 0
    if (c=='(' || c==')'||c=='['||c==']'){
        return 1;}
    return 0;
}

TToken *token(char *s) {
    static char cadena[1000];
    static char *actual;
    int k,a;
    char res[100];
    TToken *unToken;
    unToken=malloc(1*sizeof(TToken));
        if (s != NULL) {
        strcpy(cadena,s);
        actual = cadena;
        //printf("Prueba tokens1\n");
        //actual++;
    }

    while ((*actual == ' ') || (*actual =='\n') || (*actual=='\t')){
        //printf("Prueba espacio\n");
        actual++;}

    if (*actual == '\0')
        return NULL;
    if ( (esOperador(*actual) == 1) ) {
        //printf("Prueba operador\n");
        res[0] = *actual;
        res[1] = '\0';
        unToken->token[0]=res[0];
        unToken->token[1]='\0';
        unToken->tipo= 0;

        actual = actual + 1;
        return unToken;
    } else if ( (esParentesis(*actual) == 1) ) {
        //printf("Prueba parentesis\n");
        res[0] = *actual;
        res[1] = '\0';
        unToken->token[0]=res[0];
        unToken->token[1]='\0';
        unToken->tipo= 3;

        actual = actual + 1;
        return unToken;


    } else if (isdigit(*actual) || (*actual=='.')) {
        k = 0;
        while ( (*actual != '\0') && (isdigit(*actual) || *actual == '.' ) ) {
            //printf("Prueba digito\n");
            res[k] = (*actual);
            actual = actual + 1;
            unToken->token[k]=res[k];

            k = k+1;
        }
        unToken->token[k]='\0';
        unToken->tipo= 1;

        return unToken;
    } else if (isalpha(*actual)) {
        k = 0;
        while ( (*actual != '\0') && isalpha(*actual)) {
            //printf("Prueba variable\n");
            res[k] = *actual;
            actual = actual + 1;
            unToken->token[k]=res[k];
            k = k+1;
        }

        unToken->token[k]='\0';
        unToken->tipo= 2;



        return unToken;
    }

    printf("Error: expresion incorrecta");
    printf("Programa detenido");
    exit(0);
}
